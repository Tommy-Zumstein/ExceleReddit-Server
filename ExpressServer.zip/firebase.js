const firebase = {
    firebaseConfig: {
        apiKey: "AIzaSyDq4poh2b4nkc8f7QbmnSbv9-CKZ6H85NU",
        authDomain: "excelereddit4240.firebaseapp.com",
        databaseURL: "https://excelereddit4240.firebaseio.com",
        projectId: "excelereddit4240",
        storageBucket: "excelereddit4240.appspot.com",
        messagingSenderId: "981564758717",
        appId: "1:981564758717:web:c7df75f3119a21b2"
    },
    firebaseServiceAccount: {
        type: "service_account",
        project_id: "excelereddit4240",
        private_key_id: "af1328c57436b7b5ae0c9c5bedf96fd9c90efc82",
        private_key: "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCjuUY9KIMI9tXA\nC88WNADzjO0OBk8P9bsEulbQyPQSd9TJVf/63P2ZbZeX6gYf2t0wqjtYRtIiF3Dd\n9EPS4M+jIy0TWxQWUcaTXbxvqU14qqLLy+Fdadh1ZiLwCr7RXafuVF5+Zsth8ImY\nGsaxn3GAAzjbPStWhl7rKjuoSe2wxPlwD7lfBoRCFih/sT4X5ri7A+TQ+vAzMzLy\nVnY7Kw73oWl9TZhT+nBIeeTgPWk+Wm/ZgPEU9qfRkQ91pLX0mQzjNK9CmCwgyDMn\n53WtlLCRsDvk8GCYWm3xxAWqfKQtzq64k0/CuSqACIHJwJRB5m9zbKJBLW53DDA8\nB2aHBq4xAgMBAAECggEACLES5x3gQ8WQeDv1DnsZFQgfCmbDVvGQsCH3iE+V+LUF\neUebg1HgFLKz7YvhYo3xi14+MEpYm+Ud4Z3QfycRxUArNtY+LSePBzVeuTIGIg9m\nlrMhwur8Y58i4H0LJePdWmwYNO9E6Ab0OjyRqwEjIWY9l0YA2vyr/u5xcSNOy9q5\nzOtq6JoLFJV958q03++VuVoEFs7b9IvCvZwtf8zUd9FC6uNh++5zSUAOwRc4HY43\nf2pdNG09Lgjzr4b5tNNQvBMj8silr/lLiwef/qBowWDl227oW0ls+yUpxXrj/wRC\nYidkQwRTkUrtWbp85MfbJKPjFwMYHuN8FZr0F/GPEQKBgQDT0SZ9r9wtuyJzqBDu\n32e5eIn+Z2PWRj/qcHR4g6H7KU57xrdFlVj38vnMIVMgQCG+852IMc5k4PAckQqI\n0SsXThAu+Rfg/+bWNwvCicv+YwD81PThPhUAMghupWjz72G40aOMUKpaTAiG2L3n\npWox2s3JdqN6JqXKO6xgnkKMvwKBgQDF3/vn3D5+L1Hw90AEgRm/FncHBXsdNPZH\nZ+K0QZO2SDjTvj8y8xsF7JgN1Iy4XaUoryAcoSrZ3LGKI3MtJy42YMNBg510lPnx\n5umax+0emKLSyXc+yzfPtzdfYBdJzDXg4vrUKY2IvZ4DMWtvn323wvTO7JQGaoF+\nHUUPO2hRDwKBgBvstuZbCOv+f8w/m/vh+Aq7mXWwq7jUChkeOjypHfG+wFoRGJhT\n2CbYIZaHzi2yRsCl3V7XMh6aiQ07Eeh3qvank/qdXEiNdCFJoINFJ1+iLb8nVCFd\nzeb4saPkqrF+HaP//0/AUrUU0Qr2CBNB+34XGoo02diAv9qpg1A5jQyBAoGAaALp\ntiHmU4vqJaDB7NwzvWdAn9c4tMyPHE+2Mgw6admizWK2c8CoFsAb2UE9yvemhjEv\nzvzEuoowZK1nsHdk6j6IxFo7nPlmPMqlRrAKq0eOZwBxhvdpWe0z1RV8iFUoiRKm\nyHkjJZqOgZ0rnRwYCE0ZQ9/Fm23GrZUTJQOUPO8CgYEAvpN1LQr4eu5cCZjdhhuQ\nh0FGqwMjeeFtx1EiIJ6fcMvgYJ0nXl6jdcZPsMxYh/vB2N2gVMsos3YazYJwSCCc\nBvpE7AXMX7RdQ56NgZ5cNeq+Yyi2CQ37N+Spu28sgTRLvatl1E14RsuqFnX3XWJl\nAEKuqjAtErSuH0eTCoZu+ek=\n-----END PRIVATE KEY-----\n",
        client_email: "firebase-adminsdk-ag50y@excelereddit4240.iam.gserviceaccount.com",
        client_id: "102861714547026343065",
        auth_uri: "https://accounts.google.com/o/oauth2/auth",
        token_uri: "https://oauth2.googleapis.com/token",
        auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
        client_x509_cert_url: "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-ag50y%40excelereddit4240.iam.gserviceaccount.com"
    },
    firebaseURL: "https://resimplifi-fireauth.firebaseio.com",
}

module.exports = firebase;